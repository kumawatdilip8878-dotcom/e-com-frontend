import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

const CategoryForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const token = localStorage.getItem("token");
  const isEdit = !!id;

  const [categories, setCategories] = useState([]);

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    parentId: "",
    status: "Y",
  });

  const [image, setImage] = useState(null);

  useEffect(() => {
    getCategories();

    if (isEdit) {
      getCategory();
    }
  }, []);

  // Get All Categories
  const getCategories = async () => {
    try {
      const res = await axios.post(
        "http://localhost:3001/admin/allCategory",
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (res.data.success) {
        setCategories(res.data.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  // Get Single Category
  const getCategory = async () => {
    try {
      const res = await axios.post(
        "http://localhost:3001/admin/oneCategory",
        { id },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (res.data.success) {
        const data = res.data.data;

        setFormData({
          name: data.name || "",
          description: data.description || "",
          parentId: data.parentId?._id || "",
          status: data.status || "Y",
        });
      }
    } catch (error) {
      console.log(error);
    }
  };

  // Input Change
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // Submit Form
  const submitCategory = async (e) => {
    e.preventDefault();

    try {
      const data = new FormData();

      if (isEdit) {
        data.append("id", id);
      }

      data.append("name", formData.name);
      data.append("description", formData.description);
      data.append("status", formData.status);

      if (formData.parentId !== "") {
        data.append("parentId", formData.parentId);
      }

      if (image) {
        data.append("image", image);
      }

      const url = isEdit
        ? "http://localhost:3001/admin/updateCategory"
        : "http://localhost:3001/admin/category";

      const res = await axios.post(url, data, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      alert(res.data.message);

      navigate("/category");
    } catch (error) {
      console.log(error);

      alert(
        error.response?.data?.message ||
          error.message ||
          "Something went wrong"
      );
    }
  };

  return (
    <div className="category-form-page">
      <div className="form-box">

        <h2>{isEdit ? "Edit Category" : "Create Category"}</h2>

        <form onSubmit={submitCategory}>

          <input
            type="text"
            name="name"
            placeholder="Category Name"
            value={formData.name}
            onChange={handleChange}
            required
          />

          <textarea
            name="description"
            placeholder="Category Description"
            value={formData.description}
            onChange={handleChange}
            required
          />

          <select
            name="parentId"
            value={formData.parentId}
            onChange={handleChange}
          >
            <option value="">Select Parent Category</option>

            {categories
              .filter((cat) => cat._id !== id)
              .map((cat) => (
                <option key={cat._id} value={cat._id}>
                  {cat.name}
                </option>
              ))}
          </select>

          <select
            name="status"
            value={formData.status}
            onChange={handleChange}
          >
            <option value="Y">Active</option>
            <option value="N">Inactive</option>
          </select>

          <input
            type="file"
            onChange={(e) => setImage(e.target.files[0])}
          />

          <button type="submit">
            {isEdit ? "Update Category" : "Create Category"}
          </button>

        </form>

      </div>
    </div>
  );
};

export default CategoryForm;