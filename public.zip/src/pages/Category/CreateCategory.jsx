import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const CreateCategory = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const [categories, setCategories] = useState([]);

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    status: "Y",
  });

  const [image, setImage] = useState(null);

  useEffect(() => {
    getCategories();
  }, []);

  const getCategories = async () => {
    try {
      const res = await axios.post(
        "http://localhost:3001/admin/allCategory",
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (res.data.success) {
        setCategories(res.data.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const createCategory = async (e) => {
    e.preventDefault();

    try {
      const data = new FormData();

      data.append("name", formData.name);
      data.append("description", formData.description);
      data.append("status", formData.status);

    //   if (formData.parentId !== "") {
    //     data.append("parentId", formData.parentId);
    //   }

      if (image) {
        data.append("image", image);
      }

      const res = await axios.post(
        "http://localhost:3001/admin/category",
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      alert(res.data.message);

      navigate("/category");
    } catch (error) {
      console.log(error.response);

      alert(
        error.response?.data?.message ||
          error.message ||
          "Something went wrong"
      );
    }
  };

  return (
    <div className="category-form-page">
      <div className="form-box">

        <h2>Create Category</h2>

        <form onSubmit={createCategory}>

          <input
            type="text"
            name="name"
            placeholder="Category Name"
            value={formData.name}
            onChange={handleChange}
            required
          />

          <textarea
            name="description"
            placeholder="Category Description"
            value={formData.description}
            onChange={handleChange}
            required
          />

          {/* <select
            name="parentId"
            value={formData.parentId}
            onChange={handleChange}
          >
            <option value="">Select Parent Category</option>

            {categories.map((cat) => (
              <option key={cat._id} value={cat._id}>
                {cat.name}
              </option>
            ))}
          </select> */}

          <select
            name="status"
            value={formData.status}
            onChange={handleChange}
          >
            <option value="Y">Active</option>
            <option value="N">Inactive</option>
          </select>

          <input
            type="file"
            onChange={(e) => setImage(e.target.files[0])}
          />

          <button type="submit">
            Create Category
          </button>

        </form>
      </div>
    </div>
  );
};

export default CreateCategory;