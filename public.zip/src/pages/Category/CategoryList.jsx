import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const CategoryList = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const [categories, setCategories] = useState([]);

  useEffect(() => {
    getCategories();
  }, []);

  const getCategories = async () => {
    try {
      const res = await axios.post(
        "http://localhost:3001/admin/allCategory",
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (res.data.success) {
        setCategories(res.data.data);
      }
    } catch (error) {
      console.log(error);
      alert(error.response?.data?.message || "Failed to fetch categories");
    }
  };

  const deleteCategory = async (id) => {
    const confirmDelete = window.confirm(
      "Are you sure you want to delete this category?"
    );

    if (!confirmDelete) return;

    try {
      const res = await axios.post(
        "http://localhost:3001/admin/deleteCategory",
        { id },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      alert(res.data.message);
      getCategories();
    } catch (error) {
      console.log(error);
      alert(error.response?.data?.message || "Delete Failed");
    }
  };

  return (
    <div className="category-page">

      <div className="category-header">
        <h2>Category List</h2>

        <button
          className="add-btn"
          onClick={() => navigate("/category/form")}
        >
          + Add Category
        </button>
      </div>

      <div className="table-box">
        <table>

          <thead>
            <tr>
              <th>Image</th>
              <th>Name</th>
              <th>Description</th>
              <th>Status</th>
              <th>Parent</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>

            {categories.length > 0 ? (

              categories.map((item) => (

                <tr key={item._id}>

                  <td>
                    {item.image ? (
                      <img
                        src={`http://localhost:3001/${item.image}`}
                        alt="category"
                        className="category-img"
                        width="60"
                        height="60"
                      />
                    ) : (
                      "No Image"
                    )}
                  </td>

                  <td>{item.name}</td>

                  <td>{item.description}</td>

                  <td>
                    {item.status === "Y" ? (
                      <span className="active">Active</span>
                    ) : (
                      <span className="inactive">Inactive</span>
                    )}
                  </td>

                  <td>
                    {item.parentId?.name || "-"}
                  </td>

                  <td>

                    <button
                      className="edit-btn"
                      onClick={() =>
                        navigate(`/category/form/${item._id}`)
                      }
                    >
                      Edit
                    </button>

                    <button
                      className="delete-btn"
                      onClick={() => deleteCategory(item._id)}
                    >
                      Delete
                    </button>

                  </td>

                </tr>

              ))

            ) : (

              <tr>
                <td colSpan="6" style={{ textAlign: "center" }}>
                  No Category Found
                </td>
              </tr>

            )}

          </tbody>

        </table>
      </div>

    </div>
  );
};

export default CategoryList;