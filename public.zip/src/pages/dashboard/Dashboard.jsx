import { useEffect, useState } from "react";
import axios from "axios";

const Dashboard = () => {

  const [data,setData] = useState({

    category:0,
    product:0,
    user:0,
    order:0

  });


  const token = localStorage.getItem("token");


  useEffect(()=>{

    getDashboardData();

  },[]);



  const getDashboardData = async()=>{

    try{

      const res = await axios.get(

        "http://localhost:3001/admin/dashboard",

        {
          headers:{
            Authorization:`Bearer ${token}`
          }
        }

      );


      setData(res.data.data);


    }catch(error){

      console.log(error);

    }

  };



  return (

    <div className="dashboard-content">

      <h1>
        Dashboard
      </h1>


      <div className="cards">


        <div className="card">

          <h3>Categories</h3>

          <h1>{data.category}</h1>

        </div>



        <div className="card">

          <h3>Products</h3>

          <h1>{data.product}</h1>

        </div>




        <div className="card">

          <h3>Users</h3>

          <h1>{data.user}</h1>

        </div>




        <div className="card">

          <h3>Orders</h3>

          <h1>{data.order}</h1>

        </div>


      </div>


    </div>

  );

};


export default Dashboard;