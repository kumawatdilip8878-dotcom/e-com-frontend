import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const EditProfile = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const [image, setImage] = useState(null);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    mobile: "",
    gender: "",
    address: "",
  });

  useEffect(() => {
    getProfile();
  }, []);

  // Get Profile Data
  const getProfile = async () => {
    try {
      const res = await axios.post(
        "http://localhost:3001/admin/profile/get",
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      if (res.data.success) {
        const user = res.data.data;

        setFormData({
          name: user.name || "",
          email: user.email || "",
          mobile: user.mobile || "",
          gender: user.gender || "",
          address: user.address || "",
        });
      }
    } catch (error) {
      console.log(error);
    }
  };

  // Input Change
  const handleChange = (e) => {
    setFormData({
      ...formData,

      [e.target.name]: e.target.value,
    });
  };

  // Update Profile
  const updateProfile = async (e) => {
    e.preventDefault();

    try {
      const data = new FormData();

      data.append("name", formData.name);

      data.append("email", formData.email);

      data.append("mobile", formData.mobile);

      data.append("gender", formData.gender);

      data.append("address", formData.address);

      if (image) {
        data.append("profileImage", image);
      }

      const res = await axios.post(
        "http://localhost:3001/admin/profile/edit",

        data,

        {
          headers: {
            Authorization: `Bearer ${token}`,

            "Content-Type": "multipart/form-data",
          },
        },
      );

      alert(res.data.message);

      navigate("/profile");
    } catch (error) {
      console.log(error.response);

      alert(error.response?.data?.message || "Profile Update Failed");
    }
  };

  return (
    <div className="profile-page">
      <div className="profile-card">
        <h2>Edit Profile</h2>

        <form onSubmit={updateProfile}>
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={handleChange}
            required
          />

          <input
            type="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
          />

          <input
            type="text"
            name="mobile"
            placeholder="Mobile"
            value={formData.mobile}
            onChange={handleChange}
          />

          <input
            type="file"
            accept="image/*"
            onChange={(e) => setImage(e.target.files[0])}
          />

          <button type="submit">Update Profile</button>
        </form>
      </div>
    </div>
  );
};

export default EditProfile;
