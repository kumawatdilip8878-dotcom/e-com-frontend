import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Profile = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const [user, setUser] = useState({});

  useEffect(() => {
    getProfile();
  }, []);

  const getProfile = async () => {
    try {
      const res = await axios.post(
        "http://localhost:3001/admin/profile/get",
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (res.data.success) {
        setUser(res.data.data);
      }
    } catch (error) {
      console.log(error);
      alert(error.response?.data?.message || "Failed to load profile");
    }
  };

  return (
    <div className="profile-page">

      <div className="profile-card">

        <img
          src={
            user.profileImage
              ? `http://localhost:3001/${user.profileImage}`
              : "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
          }
          alt="profile"
          className="profile-photo"
        />

        <h2>{user.name}</h2>

        <table>

          <tbody>

            <tr>
              <td><b>Email</b></td>
              <td>{user.email || "-"}</td>
            </tr>

            <tr>
              <td><b>Mobile</b></td>
              <td>{user.mobile || "-"}</td>
            </tr>

            <tr>
              <td><b>Gender</b></td>
              <td>{user.gender || "-"}</td>
            </tr>

            <tr>
              <td><b>Address</b></td>
              <td>{user.address || "-"}</td>
            </tr>

          </tbody>

        </table>

        <div className="profile-btns">

          <button
            onClick={() => navigate("/profile/edit")}
          >
            Edit Profile
          </button>

          <button
            className="change-btn"
            onClick={() => navigate("/change-password")}
          >
            Change Password
          </button>

        </div>

      </div>

    </div>
  );
};

export default Profile;