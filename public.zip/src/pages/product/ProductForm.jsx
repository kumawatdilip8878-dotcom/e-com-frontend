import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

const ProductForm = () => {
  const { id } = useParams();

  const navigate = useNavigate();

  const token = localStorage.getItem("token");

  const isEdit = Boolean(id);

  const [categories, setCategories] = useState([]);

  const [images, setImages] = useState([]);

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    stock: "",
    categoryId: "",
    status: "Y",
  });

  useEffect(() => {
    getCategories();

    if (isEdit) {
      getProduct();
    }
  }, []);

  const getCategories = async () => {
    try {
      const res = await axios.post(
        "http://localhost:3001/admin/allCategory",

        {},

        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      if (res.data.success) {
        setCategories(res.data.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const getProduct = async () => {
    try {
      const res = await axios.post(
        "http://localhost:3001/admin/get/product",

        {
          id,
        },

        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      if (res.data.success) {
        const data = res.data.data;

        setFormData({
          name: data.name,

          description: data.description,

          price: data.price,

          stock: data.stock,

          categoryId: data.categoryId?._id || "",

          status: data.status,
        });
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,

      [e.target.name]: e.target.value,
    });
  };

  const submitProduct = async (e) => {
    e.preventDefault();

    try {
      const data = new FormData();

      if (isEdit) {
        data.append("id", id);
      }

      Object.keys(formData).forEach((key) => {
        data.append(key, formData[key]);
      });

      for (let i = 0; i < images.length; i++) {
        data.append("images", images[i]);
      }

      const url = isEdit
        ? "http://localhost:3001/admin/update/product"
        : "http://localhost:3001/admin/create/product";

      const res = await axios.post(
        url,

        data,

        {
          headers: {
            Authorization: `Bearer ${token}`,

            "Content-Type": "multipart/form-data",
          },
        },
      );

      alert(res.data.message);

      navigate("/product");
    } catch (error) {
      console.log(error.response);

      alert(error.response?.data?.message || "Something went wrong");
    }
  };

  return (
    <div className="category-form-page">
      <div className="form-box">
        <h2>{isEdit ? "Edit Product" : "Create Product"}</h2>

        <form onSubmit={submitProduct}>
          <input
            name="name"
            placeholder="Product Name"
            value={formData.name}
            onChange={handleChange}
          />

          <textarea
            name="description"
            placeholder="Description"
            value={formData.description}
            onChange={handleChange}
          />

          <input
            type="number"
            name="price"
            placeholder="Price"
            value={formData.price}
            onChange={handleChange}
          />

          <input
            type="number"
            name="stock"
            placeholder="Stock"
            value={formData.stock}
            onChange={handleChange}
          />

          <select
            name="categoryId"
            value={formData.categoryId}
            onChange={handleChange}
          >
            <option value="">Select Category</option>

            {categories.map((cat) => (
              <option key={cat._id} value={cat._id}>
                {cat.name}
              </option>
            ))}
          </select>

          <select name="status" value={formData.status} onChange={handleChange}>
            <option value="Y">Active</option>

            <option value="N">Inactive</option>
          </select>

          <input
            type="file"
            multiple
            onChange={(e) => setImages(e.target.files)}
          />

          <button type="submit">
            {isEdit ? "Update Product" : "Create Product"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ProductForm;
