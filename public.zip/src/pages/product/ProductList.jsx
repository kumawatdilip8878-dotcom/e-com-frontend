import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const ProductList = () => {
  const navigate = useNavigate();

  const token = localStorage.getItem("token");

  const [products, setProducts] = useState([]);

  useEffect(() => {
    getProducts();
  }, []);

  const getProducts = async () => {
    try {
      const res = await axios.post(
        "http://localhost:3001/admin/getAll/product",

        {},

        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      if (res.data.success) {
        setProducts(res.data.data);
      }
    } catch (error) {
      console.log(error);

      alert(error.response?.data?.message || "Product fetch failed");
    }
  };

  const deleteProduct = async (id) => {
    const confirm = window.confirm("Delete this product?");

    if (!confirm) return;

    try {
      const res = await axios.post(
        "http://localhost:3001/admin/delete/product",

        {
          id,
        },

        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      alert(res.data.message);

      getProducts();
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div className="category-page">
      <div className="category-header">
        <h2>Product List</h2>

        <button className="add-btn" onClick={() => navigate("/product/form")}>
          + Add Product
        </button>
      </div>

      <div className="table-box">
        <table>
          <thead>
            <tr>
              <th>Image</th>
              <th>Name</th>
              <th>Description</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Category</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {products.length > 0 ? (
              products.map((item) => (
                <tr key={item._id}>
                  <td>
                    {item.images?.length > 0 ? (
                      <img
                        src={`http://localhost:3001/uploads/product/${item.images[0]}`}
                        width="60"
                        height="60"
                        alt="product"
                      />
                    ) : (
                      "No Image"
                    )}
                  </td>

                  <td>{item.name}</td>

                  <td>{item.description}</td>

                  <td>₹ {item.price}</td>

                  <td>{item.stock}</td>

                  <td>{item.categoryId?.name || "-"}</td>

                  <td>
                    {item.status === "Y" ? (
                      <span className="active">Active</span>
                    ) : (
                      <span className="inactive">Inactive</span>
                    )}
                  </td>

                  <td>
                    <button
                      className="edit-btn"
                      onClick={() => navigate(`/product/form/${item._id}`)}
                    >
                      Edit
                    </button>

                    <button
                      className="delete-btn"
                      onClick={() => deleteProduct(item._id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="8">No Product Found</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ProductList;
