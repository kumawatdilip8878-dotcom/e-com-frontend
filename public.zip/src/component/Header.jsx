import { useEffect, useRef, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

const Header = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const [user, setUser] = useState({});
  const [open, setOpen] = useState(false);

  const dropdownRef = useRef();

  useEffect(() => {
    getProfile();

    const closeMenu = (e) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target)
      ) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", closeMenu);

    return () => {
      document.removeEventListener("mousedown", closeMenu);
    };
  }, []);

  const getProfile = async () => {
    try {
      const res = await axios.post(
        "http://localhost:3001/admin/profile/get",
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (res.data.success) {
        setUser(res.data.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const logout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <header className="header">

      <div className="logo">
        <h2>My E-Commerce</h2>
      </div>

      <nav className="nav-links">

        <Link to="/dashboard">Home</Link>

        <Link to="/category">Category</Link>

        <Link to="/product">Product</Link>

      </nav>

      <div
        className="profile-box"
        ref={dropdownRef}
      >

        <img
          src={
            user.profileImage
              ? `http://localhost:3001/${user.profileImage}`
              : "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
          }
          alt="profile"
          className="profile-img"
          onClick={() => setOpen(!open)}
        />

        {open && (
          <div className="profile-dropdown">

            <h4>{user.name}</h4>

            <p>{user.email}</p>

            <hr />

            <button
              onClick={() => navigate("/profile")}
            >
              My Profile
            </button>

            <button
              onClick={() =>
                navigate("/profile/edit")
              }
            >
              Edit Profile
            </button>

            <button
              onClick={() =>
                navigate("/change-password")
              }
            >
              Change Password
            </button>

            <button
              className="logout-btn"
              onClick={logout}
            >
              Logout
            </button>

          </div>
        )}

      </div>

    </header>
  );
};

export default Header;