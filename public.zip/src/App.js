import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Layout from "./component/Layout";

import Login from "./pages/login/Login";
import ForgotPassword from "./pages/login/ForgotPassword";
import OtpVerify from "./pages/login/OtpVerify";
import ResetPassword from "./pages/login/ResetPassword";
import Profile from "./pages/profile/Profile";
import EditProfile from "./pages/profile/EditProfile";
import ChangePassword from "./pages/profile/ChangePassword";
import CategoryList from "./pages/Category/CategoryList";
import CreateCategory from "./pages/Category/CreateCategory";
import CategoryForm from "./pages/Category/EditCategory";
import ProductForm from "./pages/product/ProductForm";
import ProductList from "./pages/product/ProductList";
import Dashboard from "./pages/dashboard/Dashboard";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}

        <Route path="/" element={<Login />} />

        <Route path="/forgot-password" element={<ForgotPassword />} />

        <Route path="/otp-verify" element={<OtpVerify />} />

        <Route path="/reset-password" element={<ResetPassword />} />

        {/* Header Layout Routes */}

        <Route element={<Layout />}>
          <Route path="/dashboard" element={<Dashboard />} />

          {/* Category CRUD */}

          <Route path="/category/create" element={<CreateCategory />} />
          <Route path="/category" element={<CategoryList />} />
          <Route path="/category/form" element={<CategoryForm />} />
          <Route path="/category/form/:id" element={<CategoryForm />} />

          <Route path="/profile" element={<Profile />} />

          <Route path="/profile/edit" element={<EditProfile />} />

          <Route path="/change-password" element={<ChangePassword />} />

      

  <Route path="/product" element={<ProductList />} />

  <Route path="/product/form" element={<ProductForm />} />

  <Route 
    path="/product/form/:id" 
    element={<ProductForm />} 
  />

</Route>
      
      </Routes>
    </BrowserRouter>
  );
}

export default App;
